# October 2026 — SCARES — 3 Word Challenge

- Host: @nebulaasgard
- Visible challenge hashtag: #3wordchallenge
- Theme: Halloween, scary, October
- Source: supplied Instagram screenshot, image(4).png.
- Schedule: October 1–31, 2026.
- Year correction: the poster's “OCTOBER 2025” is a typo. Use October 2026, as confirmed by the user.

## Source differences

The poster and caption contain different wording on several days. Both versions are preserved below. Plus signs are formatting separators added for challenge use; the source displays words on separate lines or separated by spaces. Multiword phrases are kept together according to the poster lines. Neither version has been declared authoritative by the host in the visible screenshot.

## Daily entries

| Day | Poster entry | Caption entry |
|---|---|---|
| 1 | Witches + Cauldron + Moon | Witch + Cauldron + Moon |
| 2 | Ghost + Lantern + Shadows | Ghost + Lantern + Shadows |
| 3 | Vampire + Blood + Night | Vampire + Blood + Night |
| 4 | Pumpkin + Patch + Autumn | Pumpkin + Patch + Autumn |
| 5 | Black Cat + Spells + Luck | Black Cat + Spells |
| 6 | Haunted + House + Windows | Haunted House + Windows |
| 7 | Skeleton + Bones + Ritual | Skeleton + Bones + Ritual |
| 8 | Crow + Raven + Wisdom | Crow + Raven + Omen |
| 9 | Blood Moon + Eclipse + Magic | Blood Moon + Eclipse |
| 10 | Mask + Secrets + Identity | Mask + Secrets + Identity |
| 11 | Candy + Trick + Treat | Candy + Trick + Treat |
| 12 | Spider + Web + Patience | Spider + Web + Venom |
| 13 | Werewolf + Howl + Freedom | Werewolf + Howl + Freedom |
| 14 | Bats + Chaos + Flight | Bats + Chaos + Flight |
| 15 | Tombstone + Graveyard + Rest | Tombstone + Graveyard + Rest |
| 16 | Potion + Brew + Change | Potion + Brew + Magic |
| 17 | Horror + Silence + Fear | Horror + Silence + Fear |
| 18 | Black Magic + Ritual + Power | Black Magic + Ritual |
| 19 | Fire + Ashes + Rebirth | Fire + Ashes + Rebirth |
| 20 | Doll + Broken + Memories | Doll + Broken + Memories |
| 21 | Rats + Filth + Survival | Rats + Filth + Survival |
| 22 | Poison + Kiss + Danger | Poison + Kiss + Danger |
| 23 | Fallen + Angel + Redemption | Fallen Angel + Redemption |
| 24 | Skull + Crown + Power | Skull + Crown + Power |
| 25 | Full Moon + Madness + Transformation | Full Moon + Madness |
| 26 | Coffin + Ritual + Forever | Coffin + Ritual + Forever |
| 27 | Witch + Hat + Freedom | Witch Hat + Freedom |
| 28 | Haunted + Forest + Lost | Haunted Forest + Lost |
| 29 | Jack O’Lantern + Fire + Hope | Jack O’Lantern + Fire |
| 30 | Dead + Leaves + Endings | Dead + Leaves + Endings |
| 31 | Trick or Treat + Fear + Fun | Trick + Treat + Fear |

## Visible participation requirements

The post identifies @nebulaasgard as the host and displays #3wordchallenge. No additional participation requirements or mandatory aspect ratio are visible in the supplied screenshot.
