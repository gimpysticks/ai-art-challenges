# Halloween Themes — October 2026

Host: @coiamoura.art
Required hashtag: #coiamoura2026

## Participation instructions

Use #coiamoura2026 and tag @coiamoura.art. Send the host a direct message with your post so they see your submission.

## Daily challenge entries

The numbered themes are mapped to October 1–31, 2026 for daily challenge input.

| Date | Exact prompt string |
|---|---|
| 2026-10-01 | Haunted house |
| 2026-10-02 | Pumpkin patch |
| 2026-10-03 | Full moon graveyard |
| 2026-10-04 | Witch’s cauldron |
| 2026-10-05 | Black cat |
| 2026-10-06 | Jack-o’-lantern |
| 2026-10-07 | Ghost bride |
| 2026-10-08 | Vampire castle |
| 2026-10-09 | Zombie street |
| 2026-10-10 | Werewolf forest |
| 2026-10-11 | Scarecrow field |
| 2026-10-12 | Candy corn land |
| 2026-10-13 | Skeleton dance |
| 2026-10-14 | Creepy doll |
| 2026-10-15 | Foggy swamp |
| 2026-10-16 | Abandoned carnival |
| 2026-10-17 | Corn maze |
| 2026-10-18 | Grim reaper |
| 2026-10-19 | Demon ball |
| 2026-10-20 | Cursed mirror |
| 2026-10-21 | Pumpkin king |
| 2026-10-22 | Witch’s apothecary |
| 2026-10-23 | Floating candles |
| 2026-10-24 | Ghost ship |
| 2026-10-25 | Spider web mansion |
| 2026-10-26 | Bat swarm |
| 2026-10-27 | Mummy tomb |
| 2026-10-28 | Frankenstein lab |
| 2026-10-29 | Headless horseman |
| 2026-10-30 | Poison apple |
| 2026-10-31 | Halloween free-for-all trick or treat |

## Use as challenge input

Select the entry matching the requested October date. Preserve the theme wording in challenge credits and include the host and required hashtag.

