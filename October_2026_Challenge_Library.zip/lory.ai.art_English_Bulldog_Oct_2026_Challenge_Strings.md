# English Bulldog October 2026 Challenge

- Host: @lory.ai.art
- Required hashtag: #loryaiart
- Schedule: October 1–31, 2026
- Source: supplied Instagram challenge image.

## Participation rules

1. Follow @lory.ai.art.
2. Tag @lory.ai.art in your post.
3. Use #loryaiart.

## Daily challenge strings

| Day | Exact challenge string |
|---|---|
| 1 | English Bulldog+Scarf+Orange |
| 2 | English Bulldog+Leaves+Rust |
| 3 | English Bulldog+Puddle+Copper |
| 4 | English Bulldog+Branch+Yellow |
| 5 | English Bulldog+Jumper+Brown |
| 6 | English Bulldog+Moss+Scarlet |
| 7 | English Bulldog+Pinecone+Beige |
| 8 | English Bulldog+Acorn+Pumpkin color |
| 9 | English Bulldog+Chestnut+Brick Red |
| 10 | English Bulldog+Mushroom+Straw color |
| 11 | English Bulldog+Berry+Terracotta color |
| 12 | English Bulldog+Nut+Charcoal |
| 13 | English Bulldog+Hazelnut+Ruby |
| 14 | English Bulldog+Pumpkin+Russet |
| 15 | English Bulldog+Apple+Forest Green |
| 16 | English Bulldog+Pear+Burnt Orange |
| 17 | English Bulldog+Grape+Slate Grey |
| 18 | English Bulldog+Pomegranate+Golden Yellow |
| 19 | English Bulldog+Pie+Red |
| 20 | English Bulldog+Knit hat+Taupe |
| 21 | English Bulldog+Soup+Chocolate color |
| 22 | English Bulldog+Corn+Amber |
| 23 | English Bulldog+Hay+Burgundy |
| 24 | English Bulldog+Squirrel+Olive green |
| 25 | English Bulldog+Hedgehog+Tangerine color |
| 26 | English Bulldog+Owl+Moss Green |
| 27 | English Bulldog+Scarecrow+Crimson |
| 28 | English Bulldog+Crow+Plum color |
| 29 | English Bulldog+Sweater+Ochre |
| 30 | English Bulldog+Cranberry+Maroon |
| 31 | English Bulldog+Fireplace+Grey |

