# Minii Bliss October 2026 — 31 Days of Beautifully Strange

Host: @minii.bliss.official
Challenge hashtag: #MiniiBlissOct26
Period: October 1–31, 2026

## Daily challenge entries

| Date | Exact prompt string |
|---|---|
| 2026-10-01 | October Has Arrived |
| 2026-10-02 | The Pumpkin That Glows Inside |
| 2026-10-03 | Raven Post |
| 2026-10-04 | Masquerade Moon |
| 2026-10-05 | The Friendly Shadow |
| 2026-10-06 | Potion Gone Pretty |
| 2026-10-07 | Black Cat Luck |
| 2026-10-08 | House with One Light On |
| 2026-10-09 | Candy Constellations |
| 2026-10-10 | The Midnight Carousel |
| 2026-10-11 | Spiderweb Jewels |
| 2026-10-12 | Forest of Red Umbrellas |
| 2026-10-13 | Lucky Number 13 |
| 2026-10-14 | The Skeleton’s Day Off |
| 2026-10-15 | Harvest Moon |
| 2026-10-16 | Ghost in the Greenhouse |
| 2026-10-17 | Pumpkin Head Portrait |
| 2026-10-18 | The Witch’s Lost Hat |
| 2026-10-19 | Something Under the Bed |
| 2026-10-20 | Raven & Rose |
| 2026-10-21 | The Haunted Dollhouse |
| 2026-10-22 | Autumn After Dark |
| 2026-10-23 | Monster Tea Party |
| 2026-10-24 | The House on the Hill |
| 2026-10-25 | Candy Witch |
| 2026-10-26 | Little Creature in the Fog |
| 2026-10-27 | The Ghost Train |
| 2026-10-28 | Memories in Marigolds |
| 2026-10-29 | The Night Before Halloween |
| 2026-10-30 | Trick or Treat? |
| 2026-10-31 | When Midnight Comes |

## Use as challenge input

Match the requested October date to its entry above. Preserve the exact prompt string when identifying the challenge entry. Credit @minii.bliss.official and include #MiniiBlissOct26 in challenge posts.

