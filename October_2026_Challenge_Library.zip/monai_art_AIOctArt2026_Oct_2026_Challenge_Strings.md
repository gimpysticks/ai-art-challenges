# MonAI October 2026 — AI Art Prompt Calendar

Host: @monai_art
Required hashtag: #AIOctArt2026
Period: October 1–31, 2026

## Participation instructions

Use #AIOctArt2026, tag @monai_art, and message the host your artwork to be featured in their story.

## Daily challenge entries

| Date | Exact prompt string |
|---|---|
| 2026-10-01 | Scarecrow |
| 2026-10-02 | Undead |
| 2026-10-03 | Graveyard |
| 2026-10-04 | Swamp |
| 2026-10-05 | Swing Set |
| 2026-10-06 | Orange |
| 2026-10-07 | Mad Scientist |
| 2026-10-08 | The Door in the Floor |
| 2026-10-09 | Plowed Field |
| 2026-10-10 | Goth |
| 2026-10-11 | Eerie Glow |
| 2026-10-12 | The Witch’s Trip |
| 2026-10-13 | Spooky in Magenta |
| 2026-10-14 | Unexpected Skull |
| 2026-10-15 | Sheet Ghost |
| 2026-10-16 | Pets in Costume |
| 2026-10-17 | Surreal Nightmare |
| 2026-10-18 | Plague Doctor |
| 2026-10-19 | Haunted House |
| 2026-10-20 | Black |
| 2026-10-21 | It Had a Pumpkin Head |
| 2026-10-22 | Vampire |
| 2026-10-23 | Sugar Skull |
| 2026-10-24 | Rustic Barn |
| 2026-10-25 | Potions |
| 2026-10-26 | Blood Moon |
| 2026-10-27 | Purple |
| 2026-10-28 | Clown |
| 2026-10-29 | Raven |
| 2026-10-30 | Candy |
| 2026-10-31 | Masquerade |

## Use as challenge input

Select the entry matching the requested October date. Preserve its wording when identifying the challenge. Include the host and required hashtag in challenge posts.

