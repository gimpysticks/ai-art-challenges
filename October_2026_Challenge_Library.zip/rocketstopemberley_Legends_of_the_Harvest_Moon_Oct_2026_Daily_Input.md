# Legends of the Harvest Moon — October 2026 Daily Input

- Host: @RocketsToPemberley (Instagram handle: @rocketstopemberley)
- Required challenge hashtag: #RocketsChallenge2026
- Schedule: October 1–31, 2026, assigned by the user for their own posting plan.
- The host challenge is undated and has no deadline. These are randomly selected personal daily entries, not official host-assigned daily prompts.

## Input instructions

For a requested date, use the exact Quest + Legend combination below. Each entry contains one choice from each source list. All 31 combinations are unique; individual Quests and Legends may recur. Preserve these selections rather than choosing again when this file is supplied as input.

## Participation rules

- Use any art tool of your choice.
- Keep images family-friendly.
- Post with #RocketsChallenge2026 and tag @RocketsToPemberley.
- Message the host your artwork so they do not miss your submission.
- No invitation is needed and there is no host deadline.

## Daily selections

| Date | Quest + Legend |
|---|---|
| 2026-10-01 | The Abandoned Train + Queen of the Falling Leaves |
| 2026-10-02 | The Floating Castle + The Last Autumn Dragon |
| 2026-10-03 | The Last Harvest + The Spirit of the Harvest |
| 2026-10-04 | The Mountain Pass + The Last Autumn Dragon |
| 2026-10-05 | The Road of Lanterns + The Autumn Reaper |
| 2026-10-06 | The Abandoned Train + Keeper of the Harvest Moon |
| 2026-10-07 | The Ancient Temple + The Stranger Beneath the Red Leaves |
| 2026-10-08 | The Forbidden Forest + Guardian of the Red Forest |
| 2026-10-09 | The Witch’s Cottage + The Last Autumn Dragon |
| 2026-10-10 | The Forgotten Mine + The Orchard Keeper |
| 2026-10-11 | The Mountain Pass + The Witch of the Harvest |
| 2026-10-12 | The Forbidden Forest + The Witch of the Harvest |
| 2026-10-13 | The Forgotten Mine + Queen of the Falling Leaves |
| 2026-10-14 | The Witch’s Cottage + The Lantern Bearer |
| 2026-10-15 | The Ruins Beneath the Leaves + The Fox King |
| 2026-10-16 | The Valley Beyond the Map + The Moonlit Wanderer |
| 2026-10-17 | The Witch’s Cottage + The Tree That Walks at Night |
| 2026-10-18 | The Forbidden Forest + The Harvest Giant |
| 2026-10-19 | The Mountain Pass + The Autumn Reaper |
| 2026-10-20 | The Haunted Village + The Tree That Walks at Night |
| 2026-10-21 | The Valley Beyond the Map + The Fox King |
| 2026-10-22 | The Ancient Temple + The Autumn Reaper |
| 2026-10-23 | The Abandoned Train + The Harvest Giant |
| 2026-10-24 | The Secret Garden + The Stranger Beneath the Red Leaves |
| 2026-10-25 | The Mountain Pass + The Lantern Bearer |
| 2026-10-26 | The Last Harvest + The Fox King |
| 2026-10-27 | The Haunted Village + The Harvest Giant |
| 2026-10-28 | The Mountain Pass + The Spirit of the Harvest |
| 2026-10-29 | The Witch’s Cottage + The Fox King |
| 2026-10-30 | The Autumn Coast + Spirit of the First Frost |
| 2026-10-31 | The Forbidden Forest + The Fox King |
