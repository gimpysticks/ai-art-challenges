# October 2026 — Vampire Aesthetic Challenge

- Host: @_cora_coon
- Challenge hashtag: #OCTtrash26
- Schedule: October 1–31, 2026
- Theme: Vampire Aesthetic
- Theme description from the post: Crimson velvet, gothic architecture, and eternal nights.
- Source: supplied Instagram screenshot (image(3).png).

## Source requirements

The screenshot supplies the theme, host, hashtag, and daily entries. No additional participation rules or required aspect ratio are visible. The year 2026 is inferred from the hashtag and current October challenge context; the poster itself says October.

## Daily challenge entries

| October day | Exact prompt string |
|---|---|
| 1 | Gothic Manor |
| 2 | Black Lace |
| 3 | Family Vault |
| 4 | Forbidden Seduction |
| 5 | Broken Statue |
| 6 | Sharp Fangs |
| 7 | Vintage Decanter |
| 8 | Velvet Choker |
| 9 | Wrought Iron |
| 10 | Blood Pact |
| 11 | Midnight Masquerade |
| 12 | Pale Complexion |
| 13 | Phantom Carriage |
| 14 | Chilling Kiss |
| 15 | Bat Colony |
| 16 | Red Jewel |
| 17 | Ancestral Curse |
| 18 | Silk Fan |
| 19 | Candelabra Glow |
| 20 | Crimson Stain |
| 21 | Secret Garden |
| 22 | Dark Romance |
| 23 | Heavy Cloak |
| 24 | Nocturnal Hunt |
| 25 | Shattered Mirror |
| 26 | Bleeding Rose |
| 27 | Shadow Step |
| 28 | White Snake |
| 29 | Magnificent Marble |
| 30 | Moonlit Balcony |
| 31 | Opulent Coffin |

